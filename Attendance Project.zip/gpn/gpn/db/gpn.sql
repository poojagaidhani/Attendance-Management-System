-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2018 at 05:52 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gpn`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(10) NOT NULL,
  `subject_id` int(10) NOT NULL,
  `student_id` int(10) NOT NULL,
  `present` enum('0','1') NOT NULL COMMENT '0- absent, 1- present',
  `date` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `subject_id`, `student_id`, `present`, `date`) VALUES
(1, 26, 20, '1', '2018-03-14'),
(2, 26, 22, '1', '2018-03-14'),
(3, 26, 23, '0', '2018-03-14');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `id` int(10) NOT NULL,
  `branch_name` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `branch_name`) VALUES
(1, 'Computer Technology'),
(2, 'Information Technology');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(10) NOT NULL,
  `course_name` varchar(600) NOT NULL,
  `course_code` int(50) NOT NULL,
  `branch` int(10) NOT NULL,
  `year` int(10) NOT NULL,
  `term` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `course_name`, `course_code`, `branch`, `year`, `term`) VALUES
(1, 'Basic Mathematic', 6103, 1, 1, 1),
(2, 'Applied Physics', 6105, 1, 1, 1),
(3, 'Engineering Graphics', 6107, 1, 1, 1),
(4, 'Computer Fundamentals and Organization', 6117, 1, 1, 1),
(5, 'Computer Workshop1 Practice', 6119, 1, 1, 1),
(6, 'Environmental Studies', 6302, 1, 1, 1),
(7, 'Engineering Mathematics', 6104, 1, 1, 2),
(8, 'Applied Chemistry ', 6106, 1, 1, 2),
(9, 'Communication Skill', 6101, 1, 1, 2),
(10, 'Elements of Electronics', 6118, 1, 1, 2),
(11, 'Fundamental Electrical Techonology', 6113, 1, 1, 2),
(12, 'Programming in C', 6237, 1, 1, 2),
(13, 'Webpage Design', 6241, 1, 2, 3),
(14, 'PC Architecture and Maintainance', 6239, 1, 2, 3),
(15, 'Datastructure Using C', 6235, 1, 2, 3),
(16, 'Database Management System', 6236, 1, 2, 3),
(17, 'Digital Techniques', 6436, 1, 2, 3),
(18, 'Marketing Management', 6306, 1, 2, 3),
(19, 'Industrial Oranization and Management', 6303, 1, 2, 4),
(20, 'Data Communication and Networking', 6303, 1, 2, 4),
(21, 'Object Oriented Programming', 6238, 1, 2, 4),
(22, 'Microprocessor', 6234, 1, 2, 4),
(23, 'Applied Mathematics', 6301, 1, 2, 4),
(24, 'Software Engineering', 6434, 1, 2, 4),
(25, 'Scripting Technology', 6439, 1, 2, 4),
(26, 'Java Programming', 6437, 1, 3, 5),
(27, 'Web Programming and Technology', 0, 1, 3, 5),
(28, 'Enterprice Database Management', 0, 1, 3, 5),
(29, 'Operating System Architecture', 0, 1, 3, 5),
(30, 'Software Project Management', 0, 1, 3, 5),
(31, 'Communication Technology', 0, 1, 3, 5),
(32, 'Seminar', 0, 1, 3, 5),
(33, 'Linux Operating System', 6545, 1, 3, 6),
(34, 'Advance Java', 6544, 1, 3, 6),
(35, 'PHP Programming', 6541, 1, 3, 6),
(36, 'Project', 0, 1, 3, 6),
(37, 'Management Information System', 0, 1, 3, 6),
(38, 'Software Testing', 0, 1, 3, 6),
(39, 'Professional Practices', 0, 1, 3, 6),
(40, 'Basic Mathematic', 6103, 2, 1, 1),
(41, 'Applied Physics', 6105, 2, 1, 1),
(42, 'Engineering Graphics', 6107, 2, 1, 1),
(43, 'Management Information System', 0, 2, 3, 6),
(44, 'Computer Fundamentals and Organization', 6117, 2, 1, 1),
(45, 'Computer Workshop1 Practice', 6119, 2, 1, 1),
(46, 'Environmental Studies', 6302, 2, 1, 1),
(47, 'Engineering Mathematics', 6104, 2, 1, 2),
(48, 'Applied Chemistry ', 6106, 2, 1, 2),
(49, 'Communication Skill', 6101, 2, 1, 2),
(50, 'Elements of Electronics', 6118, 2, 1, 2),
(51, 'Fundamental Electrical Techonology', 6113, 2, 1, 2),
(52, 'Programming in C', 6237, 2, 1, 2),
(53, 'Webpage Design', 6241, 2, 2, 3),
(54, 'PC Architecture and Maintainance', 6239, 2, 2, 3),
(55, 'Datastructure Using C', 6235, 2, 2, 3),
(56, 'Database Management System', 6236, 2, 2, 3),
(57, 'Marketing Management', 6306, 2, 2, 3),
(58, 'Industrial Oranization and Management', 6303, 2, 2, 4),
(59, 'Data Communication and Networking', 6303, 2, 2, 4),
(60, 'Object Oriented Programming', 6238, 2, 2, 4),
(61, 'Microprocessor', 6234, 2, 2, 4),
(62, 'Applied Mathematics', 6301, 2, 2, 4),
(63, 'Software Engineering', 6434, 2, 2, 4),
(64, 'Scripting Technology', 6439, 2, 2, 4),
(65, 'Java Programming', 6437, 2, 3, 5),
(66, 'Web Programming and Technology', 0, 2, 3, 5),
(67, 'Enterprice Database Management', 0, 2, 3, 5),
(68, 'Operating System Architecture', 0, 2, 3, 5),
(69, 'Software Project Management', 0, 2, 3, 5),
(70, 'Communication Technology', 0, 2, 3, 5),
(71, 'Seminar', 0, 2, 3, 5),
(72, 'Linux Operating System', 6545, 2, 3, 6),
(73, 'Advance Java', 6544, 2, 3, 6),
(74, 'PHP Programming', 6541, 2, 3, 6),
(75, 'Project', 0, 2, 3, 6),
(76, 'Management Information System', 0, 2, 3, 6),
(77, 'Software Testing', 0, 2, 3, 6),
(78, 'Professional Practices', 0, 2, 3, 6);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(12) NOT NULL,
  `fullname` varchar(250) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` int(5) NOT NULL,
  `terms` tinyint(1) NOT NULL,
  `activation` int(12) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `year_id` int(11) NOT NULL,
  `sem_id` int(11) NOT NULL,
  `roll_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `fullname`, `email`, `password`, `usertype`, `terms`, `activation`, `branch_id`, `year_id`, `sem_id`, `roll_no`) VALUES
(10, 'swapnali', 'swapnali@gmail.com', '2d592cd6f6338d99d879cddeb9e51219', 2, 1, 1, 0, 0, 0, 0),
(11, 'Pooja Patil', 'pooja@gmail.com', '83b4ef5ae4bb360c96628aecda974200', 4, 1, 0, 0, 0, 0, 0),
(12, 'Pallavi Dhokane', 'pallavidhokane@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 4, 1, 0, 0, 0, 0, 0),
(13, 'Ravina', 'ravina@gmail.com', '2d592cd6f6338d99d879cddeb9e51219', 4, 1, 0, 0, 0, 0, 0),
(14, 'jivan', 'jivan@gmail.com', '83b4ef5ae4bb360c96628aecda974200', 3, 1, 0, 0, 0, 0, 0),
(15, 'komal', 'komal@gmail.com', '83b4ef5ae4bb360c96628aecda974200', 3, 1, 0, 0, 0, 0, 0),
(16, 'bharati', 'bharati@gmail.com', '2d592cd6f6338d99d879cddeb9e51219', 4, 1, 0, 0, 0, 0, 0),
(17, 'Bhavana', 'bhavana@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 2, 1, 0, 0, 0, 0, 0),
(18, 'Bhavana Shirude', 'bha@gmail.com', '202cb962ac59075b964b07152d234b70', 1, 1, 1, 0, 0, 0, 0),
(19, 'Nayana', 'nayana@gmail.com', '202cb962ac59075b964b07152d234b70', 1, 1, 0, 0, 0, 0, 0),
(20, 'Akash Shirude', 'akash@gmail.com', '202cb962ac59075b964b07152d234b70', 4, 1, 0, 1, 3, 5, 0),
(21, 'bss', 'bss@gmail.com', '202cb962ac59075b964b07152d234b70', 3, 1, 1, 0, 0, 0, 0),
(22, 'Aishwarya', 'aish@gmail.com', '202cb962ac59075b964b07152d234b70', 4, 1, 1, 1, 3, 5, 6),
(23, 'Nikita Dusane', 'nikita@gmail.com', '202cb962ac59075b964b07152d234b70', 4, 1, 0, 1, 3, 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `semister`
--

CREATE TABLE `semister` (
  `id` int(10) NOT NULL,
  `semister_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semister`
--

INSERT INTO `semister` (`id`, `semister_name`) VALUES
(1, 'First Term'),
(2, 'Second Term'),
(3, 'Third Term'),
(4, 'Fourth Term'),
(5, 'Fifth Term'),
(6, 'Sixth Term');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `lecturer_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `activation` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `lecturer_id`, `course_id`, `activation`) VALUES
(1, 21, 26, 1),
(2, 21, 58, 1);

-- --------------------------------------------------------

--
-- Table structure for table `usertypes`
--

CREATE TABLE `usertypes` (
  `id` int(2) NOT NULL,
  `name` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertypes`
--

INSERT INTO `usertypes` (`id`, `name`) VALUES
(1, 'Principal'),
(2, 'Head of Department'),
(3, 'Lecturer'),
(4, 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `year`
--

CREATE TABLE `year` (
  `id` int(10) NOT NULL,
  `year_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `year`
--

INSERT INTO `year` (`id`, `year_name`) VALUES
(1, 'First Year'),
(2, 'Second Year'),
(3, 'Third Year');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semister`
--
ALTER TABLE `semister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usertypes`
--
ALTER TABLE `usertypes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `year`
--
ALTER TABLE `year`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `semister`
--
ALTER TABLE `semister`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `year`
--
ALTER TABLE `year`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
