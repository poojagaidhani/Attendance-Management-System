<?php

error_reporting(0);

include 'DbConnection.php';

$id = $_GET['id'];

$select = "select * from attendance where id=$id";

$result = mysqli_query($con,$select);

$row = mysqli_fetch_row($result);

if($row[3] == 1)
{
	echo $query = "update attendance set present='0' where id=$id";
	$result = mysqli_query($con,$query);

	if(!mysqli_affected_rows($result))
	{
			echo"<script type='text/javascript'>
			confirm('Attendance Updated successfully')
			</script>";

			header('Location:edit_attendance.php');
	}
	else
	{
			echo"<script type='text/javascript'>
			alert('Something went wrong please try again')
			</script>";
	}
}
else
{
	echo $query1 = "update attendance set present='1' where id=$id";
	$result1 = mysqli_query($con,$query1);

	if(!mysqli_affected_rows($result1))
	{
			echo"<script type='text/javascript'>
			confirm('Attendance Updated successfully')
			</script>";

			header('Location:edit_attendance.php');
	}
	else
	{
			echo"<script type='text/javascript'>
			alert('Something went wrong please try again')
			</script>";
	}
}


?>