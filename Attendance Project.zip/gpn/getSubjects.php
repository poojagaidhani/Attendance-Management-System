<?php

include 'DbConnection.php';


$query = "SELECT * FROM course WHERE branch = '".$_POST['branch']."' AND year = '".$_POST['year']."' AND term = '".$_POST['sem']."'";

$row = mysqli_query($con,$query);

echo "<option value=''>Select Subject</option>";
while($data = mysqli_fetch_assoc($row))
{
  echo "<option value='".$data['id']."'>".$data['course_name']."</option>";
}
?>