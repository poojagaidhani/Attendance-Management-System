<?php
include 'DbConnection.php';

$attendance = mysqli_query($con,"SELECT DISTINCT(student_id) FROM attendance");

$arr_attendance = [];

if($attendance)
{
	while ($row = mysqli_fetch_assoc($attendance))
	{
		$arr_attendance[] = $row;	
	}	
}

foreach ($arr_attendance as $key => $student) 
{

	$res = mysqli_query($con,'SELECT student_id, COUNT(IF(attendance.present = "1",1,NULL)) as present_count, COUNT(IF(attendance.present = "0",1,NULL)) as absent_count FROM attendance where student_id = "'.$student["student_id"].'"');

	while($row = mysqli_fetch_array($res))
	{
		echo '<pre>';
		print_r($row);
	}
}




?>