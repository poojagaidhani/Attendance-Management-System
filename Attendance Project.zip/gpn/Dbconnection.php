 <?php
$host='localhost';
$user='root';
$pass='';
$dbname='gpn';
$con=mysqli_connect($host,$user,$pass,$dbname) or die('Uanble to connect');
//mysqlii_select_db($con,$dbname) or die('select Database');
//mysqli_query('SET character_set_result=utf8',$con);
?>