<?php

error_reporting(0);

include 'DbConnection.php';

$id = $_GET['id'];

$select = "select * from subject where id=$id";

$result = mysqli_query($con,$select);

$row = mysqli_fetch_row($result);

if($row[3] == 1)
{
	$query = "update subject set activation=0 where id=$id";
	$result = mysqli_query($con,$query);

	if(!mysqli_affected_rows($result))
	{
			echo"<script type='text/javascript'>
			confirm('Subject Deactivated successfully')
			</script>";

			header('Location:activate_subject.php');
	}
	else
	{
			echo"<script type='text/javascript'>
			alert('Something went wrong please try again')
			</script>";
	}
}
else
{
	$query = "update subject set activation=1 where id=$id";
	$result = mysqli_query($con,$query);

	if(!mysqli_affected_rows($result))
	{
			echo"<script type='text/javascript'>
			confirm('Subject Activated successfully')
			</script>";

			header('Location:activate_subject.php');
	}
	else
	{
			echo"<script type='text/javascript'>
			alert('Something went wrong please try again')
			</script>";
	}
}


?>