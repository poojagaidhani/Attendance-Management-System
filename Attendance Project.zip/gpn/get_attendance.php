<?php
include 'DbConnection.php';
$subject_id = $_POST['subject_id'];
$date = date('Y-m-d',strtotime($_POST['datepicker']));

/*echo $date;
echo $subject_id;
exit;*/

//$course_res = mysqli_query($con, "SELECT * FROM attendance WHERE id = '".$branch_id."'");

$attendance_res =  mysqli_query($con,
                        "SELECT 
                            attendance.id as aid,
                            attendance.subject_id,
                            attendance.student_id, 
                            attendance.present,
                            attendance.date,

                            course.id as cid,
                            course.course_name,
                            
                           
                            FROM attendance a
								JOIN course c
									 ON  a.subject_id =c.id 
								
									 	 ");

$arr_product = [];

if($attendance_res)
{
    while ($row = mysqli_fetch_assoc($attendance_res))
    {
        $arr_product[] = $row;  
    }   
}

echo '<pre>';
print_r($arr_product);
exit;

$user_arr = mysqli_query($con,"SELECT * FROM register WHERE branch_id = '".$course_arr[3]."' AND year_id = '".$course_arr[4]."' AND sem_id = '".$course_arr[5]."'");

$user_records_arr = [];
foreach ($user_arr as $key => $user)
{
	$user_records_arr[] = $user;
}

echo json_encode($user_records_arr);
?>