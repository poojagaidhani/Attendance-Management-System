<?php
include 'DbConnection.php';
$branch_id = $_POST['branch_id'];

$course_res = mysqli_query($con, "SELECT * FROM course WHERE id = '".$branch_id."'");

$course_arr = mysqli_fetch_row($course_res);

$user_arr = mysqli_query($con,"SELECT * FROM register WHERE branch_id = '".$course_arr[3]."' AND year_id = '".$course_arr[4]."' AND sem_id = '".$course_arr[5]."'");

$user_records_arr = [];
foreach ($user_arr as $key => $user)
{
	$user_records_arr[] = $user;
}

echo json_encode($user_records_arr);
?>